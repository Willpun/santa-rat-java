/** Automatically generated file. DO NOT MODIFY */
package com.playanywhere.santa.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}